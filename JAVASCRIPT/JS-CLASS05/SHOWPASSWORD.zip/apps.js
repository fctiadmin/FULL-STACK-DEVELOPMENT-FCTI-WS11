function myCheck(){
	var pass1=document.getElementById('password');
	var pass2=document.getElementById('c_password');
	if(pass1.type=="password" || pass2.type=="password"){
		pass1.type="text";
		pass2.type="text";
	}else{
			pass1.type="password";
		pass2.type="password";
	}
	
}
var username=document.getElementById('username');
var icon1=document.querySelector('.icon-1')
username.addEventListener('keyup',function(e){
	if(username.value.length>0){
		username.style.border='2px solid green';  
		icon1.style.color='green';
	}else{
		username.style.border='2px solid red';
		icon1.style.color='red';
	}

})